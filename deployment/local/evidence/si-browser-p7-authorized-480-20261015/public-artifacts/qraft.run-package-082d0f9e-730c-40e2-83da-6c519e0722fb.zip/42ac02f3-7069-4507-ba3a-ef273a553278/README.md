# 42ac02f3-7069-4507-ba3a-ef273a553278

Self-contained QRAFT 0.2 canonical-runtime package. Compatibility translation
loads `campaign.yaml`, then `CompiledWorkflowRuntime` owns DAG state, resources,
attempts and recovery inside the allocation. Historical controller state is
handled only through the explicit compatibility API.

```bash
python3 verify_package.py
chmod +x progress.sh
sbatch --test-only submit.slurm
sbatch submit.slurm
./progress.sh
```
