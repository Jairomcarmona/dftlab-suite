#!/usr/bin/env python3
from pathlib import Path
from qraft.execution.campaign_progress import read_campaign_progress,render_campaign_progress
print(render_campaign_progress(read_campaign_progress(Path("."))))
