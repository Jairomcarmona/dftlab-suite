#!/usr/bin/env python3
import hashlib,json,re,subprocess,sys
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
def fail(code,detail=""): raise SystemExit(code+(":"+detail if detail else ""))
manifest=json.loads((root/"manifest.json").read_text(encoding="utf-8"))
if manifest.get("package_id")!='42ac02f3-7069-4507-ba3a-ef273a553278': fail("PACKAGE_ID_MISMATCH")
for name,expected in manifest.get("immutable_files",{}).items():
 p=PurePosixPath(name)
 if p.is_absolute() or ".." in p.parts or "\\" in name: fail("UNSAFE_PATH",name)
 target=root.joinpath(*p.parts)
 if not target.is_file() or target.is_symlink(): fail("MISSING_IMMUTABLE_FILE",name)
 if hashlib.sha256(target.read_bytes()).hexdigest()!=expected: fail("IMMUTABLE_HASH_MISMATCH",name)
seen=set()
for line in (root/"checksums.sha256").read_text(encoding="utf-8").splitlines():
 m=re.fullmatch(r"([0-9a-f]{64})\s+(.+)",line)
 if not m: fail("INVALID_CHECKSUM_LINE",line)
 expected,name=m.groups()
 if name in seen: fail("DUPLICATE_CHECKSUM",name)
 seen.add(name); target=root.joinpath(*PurePosixPath(name).parts)
 if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=expected: fail("CHECKSUM_MISMATCH",name)
mutable={"state","work","results","evidence"}
actual={p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p.name!="qraft.out" and p.relative_to(root).parts[0] not in mutable and not p.name.startswith(("OUT.","ERROR."))}
if actual != seen|{"checksums.sha256"}: fail("CHECKSUM_COVERAGE_MISMATCH",str(sorted(actual^(seen|{"checksums.sha256"}))))
sys.path.insert(0,str(root/"runtime"))
from qraft.execution.allocation_controller import load_controller_config
load_controller_config(root/"campaign.yaml")
worker=(root/"scripts/run_worker.py").read_text(encoding="utf-8")
if "CanonicalController" not in worker or "AllocationController.from_file" in worker: fail("CANONICAL_RUNTIME_ENTRY_REQUIRED")
if (root/"run.lock.json").is_file():
 run=json.loads((root/"run.lock.json").read_text(encoding="utf-8"))
 resolution=run.get("payload",{}).get("metadata",{}).get("execution_resolution")
 if isinstance(resolution,dict) and resolution.get("resolution_mode")!="PROFILE_ALREADY_RESOLVED":
  if resolution.get("human_confirmed") is not True: fail("HUMAN_CONFIRMATION_REQUIRED")
  campaign=json.loads((root/"campaign.yaml").read_text(encoding="utf-8"))
  expected={"selected_partition":campaign["slurm"]["partition"],"selected_account":campaign["slurm"].get("account"),"selected_qos":campaign["slurm"].get("qos"),"selected_nodes":campaign["resources"]["nodes"],"selected_total_ranks":campaign["resources"].get("ntasks",campaign["resources"]["total_cpus"]),"selected_walltime":campaign["resources"]["walltime"]}
  if any(resolution.get(key)!=value for key,value in expected.items()): fail("RUN_LOCK_SUBMIT_COHERENCE_MISMATCH")
  directives={}
  for line in (root/"submit.slurm").read_text(encoding="utf-8").splitlines():
   match=re.fullmatch(r"#SBATCH --([^=]+)=(.+)",line)
   if match: directives[match.group(1)]=match.group(2)
  if directives.get("partition")!=expected["selected_partition"] or directives.get("account")!=expected["selected_account"] or directives.get("qos")!=expected["selected_qos"] or directives.get("nodes")!=str(expected["selected_nodes"]) or directives.get("ntasks")!=str(expected["selected_total_ranks"]) or directives.get("time")!=expected["selected_walltime"]: fail("RUN_LOCK_SUBMIT_COHERENCE_MISMATCH")
for path in ("submit.slurm","progress.sh"):
 result=subprocess.run(["bash","-n",path],cwd=root,capture_output=True,text=True)
 if result.returncode: fail("BASH_SYNTAX_FAILURE",result.stderr.strip())
print("QRAFT_CONTROLLER_PACKAGE_VERIFIED")
print("NO_LOGIN_PERSISTENT_PROCESS_REQUIRED")
