#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
cd "$ROOT"
export PYTHONPATH="$ROOT/runtime"
export PYTHONDONTWRITEBYTECODE=1
python3 scripts/progress.py
echo
echo "=== SLURM DEL USUARIO ==="
squeue -u "$USER" || true
