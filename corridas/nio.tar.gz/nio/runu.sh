#!/bin/bash
cd /opt/run/nio
while ! grep -q SCDONE /tmp/claude-0/-home-claude/d87ddaff-ef85-5955-9e4b-2e2775a6c709/tasks/b7o6hir0s.output; do sleep 20; done
n=$(python3 gen.py 13.8); cd $n; OMP_NUM_THREADS=2 /opt/siesta/bin/siesta $n.fdf > $n.out 2>&1; cd ..; echo "$n done"; echo UDONE
