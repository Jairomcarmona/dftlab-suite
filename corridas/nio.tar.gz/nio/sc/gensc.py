import os,sys,shutil
n1,n2,n3=map(int,sys.argv[1].split('x')); alpha=float(sys.argv[2]); mode=sys.argv[3]  # ground|bare|scf
a=4.17; A=[[a,a/2,a/2],[a/2,a,a/2],[a/2,a/2,a]]
L=[[x*n for x in v] for v,n in zip(A,(n1,n2,n3))]
base=[(0,0,0,'Ni1'),(.5,.5,.5,'Ni2'),(.25,.25,.25,'O'),(.75,.75,.75,'O')]
at=[]
for i in range(n1):
  for j in range(n2):
    for k in range(n3):
      for f in base: at.append(((f[0]+i)/n1,(f[1]+j)/n2,(f[2]+k)/n3,f[3]))
at[0]=at[0][:3]+('Nip',)
sp={'Ni1':1,'Ni2':2,'O':3,'Nip':4}
nat=len(at); kg=[max(1,round(6/n)) for n in (n1,n2,n3)]
tag=f'{n1}x{n2}x{n3}'
name=f'{tag}_{mode}' if mode=='ground' else f'{tag}_{mode}_{"p" if alpha>0 else "m"}{abs(alpha)*100:03.0f}'
s=f"""SystemLabel {name}
XC.functional GGA
XC.authors PBE
NumberOfSpecies 4
NumberOfAtoms {nat}
%block ChemicalSpeciesLabel
 1 28 Ni1
 2 28 Ni2
 3 8 O
 4 28 Nip
%endblock ChemicalSpeciesLabel
PAO.BasisSize DZP
PAO.EnergyShift 50 meV
LatticeConstant 1.0 Ang
%block LatticeVectors
"""+''.join(' '.join(f'{x:.6f}' for x in v)+'\n' for v in L)+"""%endblock LatticeVectors
AtomicCoordinatesFormat Fractional
%block AtomicCoordinatesAndAtomicSpecies
"""+''.join(f'{x:.6f} {y:.6f} {z:.6f} {sp[e]}\n' for x,y,z,e in at)+f"""%endblock AtomicCoordinatesAndAtomicSpecies
MeshCutoff 300 Ry
%block kgrid_Monkhorst_Pack
 {kg[0]} 0 0 0.0
 0 {kg[1]} 0 0.0
 0 0 {kg[2]} 0.0
%endblock kgrid_Monkhorst_Pack
Spin polarized
%block DM.InitSpin
"""+''.join(f' {i+1} {"+" if e in("Ni1","Nip") else "-"}\n' for i,(x,y,z,e) in enumerate(at) if e!='O')+f"""%endblock DM.InitSpin
ElectronicTemperature 100 K
SCF.Mixer.Method {'linear' if mode=='bare' else 'Pulay'}
SCF.Mixer.Weight {'1.0' if mode=='bare' else '0.1'}
SCF.Mixer.History 8
MaxSCFIterations {1 if mode=='bare' else 300}
SCF.MustConverge {'F' if mode=='bare' else 'T'}
SCF.DM.Tolerance 1.e-4
DM.UseSaveDM T
LongOutput T
DFTU.PotentialShift T
DFTU.FirstIteration T
%block DFTU.Proj
"""+''.join(f' {e} 1\n n=3 2\n {(alpha if e=="Nip" and mode!="ground" else 0):.4f} 0.00\n 0.00 0.00\n' for e in ('Nip','Ni1','Ni2'))+"%endblock DFTU.Proj\n"
os.makedirs(name,exist_ok=True); open(f'{name}/{name}.fdf','w').write(s)
for f in ['Ni1','Ni2','O','Nip']: shutil.copy(f+'.psml',name)
if mode!='ground': shutil.copy(f'{tag}_ground/{tag}_ground.DM',f'{name}/{name}.DM')
print(name)
