#!/bin/bash
cd /opt/run/nio/sc
for t in 2x1x1 2x2x1; do
 for job in "0 ground" "0.1 bare" "-0.1 bare" "0.1 scf" "-0.1 scf"; do
  n=$(python3 gensc.py $t $job); [ -f $n/$n.out ] && grep -q "Job completed" $n/$n.out && continue
  cd $n; s=$(date +%s); OMP_NUM_THREADS=2 /opt/siesta/bin/siesta $n.fdf > $n.out 2>&1; cd ..
  echo "$n $(( $(date +%s)-s ))s $(grep -c 'Occupations:' $n/$n.out)"
 done
done
echo SCDONE
