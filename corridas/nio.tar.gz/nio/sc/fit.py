import re,json,sys,os
def occ(f,nNi):
    t=open(f).read(); L=re.findall(r'Occupations:\s+\S+\s+\S+\s+(\S+)',t); return [float(x) for x in L[-nNi:]]
res=[]
for tag,nNi in (('2x1x1',4),('2x2x1',8)):
    try:
        N0=occ(f'{tag}_ground/{tag}_ground.out',nNi)
        d={m:{a:occ(f'{tag}_{m}_{s}/{tag}_{m}_{s}.out',nNi) for a,s in ((0.1,'p010'),(-0.1,'m010'))} for m in ('bare','scf')}
    except Exception as e: print(tag,'incompleto',e); continue
    chi0=(d['bare'][0.1][0]-d['bare'][-0.1][0])/0.2; chi=(d['scf'][0.1][0]-d['scf'][-0.1][0])/0.2
    r=dict(cell=tag,nat=nNi*2,N0=N0[0],chi0=chi0,chi=chi,U=1/chi0-1/chi,bare=d['bare'],scf=d['scf'],sum0=sum((d['bare'][0.1][i]-d['bare'][-0.1][i])/0.2 for i in range(nNi)),sum=sum((d['scf'][0.1][i]-d['scf'][-0.1][i])/0.2 for i in range(nNi)))
    res.append(r); print(tag,{k:round(v,4) for k,v in r.items() if isinstance(v,float)})
if '--write' in sys.argv:
    p='/mnt/project-files/DFT_App/app/dftlab/static/js/data/nio.json'; D=json.load(open(p))
    D['lr']['cells']=[{'cell':'1×1×1','nat':4,'chi0':D['lr']['chi0'],'chi':D['lr']['chi'],'U':D['lr']['U']}]+[{k:r[k] for k in ('cell','nat','chi0','chi','U')} for r in res]
    for c in D['lr']['cells']: c['cell']=c['cell'].replace('x','×')
    json.dump(D,open(p,'w'),separators=(',',':'))
