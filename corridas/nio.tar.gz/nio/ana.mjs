import { readFileSync } from 'node:fs';
import { parseEIG, parseKP, analyzeGap, parseOut, parsePDOS, groupPDOS } from '/mnt/project-files/DFT_App/app/dftlab/static/js/siesta/index.js';
for (const u of [0,2,4,6,8]) { const d=`u${u}`;
 const e=parseEIG(readFileSync(`${d}/${d}.EIG`,'utf8'), readFileSync(`${d}/${d}.KP`,'utf8')); const g=analyzeGap(e);
 const o=parseOut(readFileSync(`${d}/${d}.out`,'utf8'));
 const m=o.populations?.mulliken; console.log(u,'gap',g.gap?.toFixed(3),g.type,'Etot',o.final.etot,'mom',m?.atoms.map(a=>a.Sz?.toFixed(3)).join(' '),'conv',o.final.scfConverged,'t',o.timers?.wallTime);
}
