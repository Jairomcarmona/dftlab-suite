import os,sys,shutil
alpha=float(sys.argv[1]); mode=sys.argv[2]  # bare|scf
name=f'lr_{mode}_{alpha:+.2f}'.replace('+','p').replace('-','m').replace('.','')
base=open('u0/u0.fdf').read().replace('SystemLabel u0','SystemLabel '+name)
base=base.replace('SCF.Mixer.Method Pulay','SCF.Mixer.Method '+('linear' if mode=='bare' else 'Pulay'))
if mode=='bare': base=base.replace('SCF.Mixer.Weight 0.1','SCF.Mixer.Weight 1.0').replace('MaxSCFIterations 300','MaxSCFIterations 1\nSCF.MustConverge F')
base=base.replace('%block ProjectedDensityOfStates','%block ProjectedDensityOfStatesX').replace('%endblock ProjectedDensityOfStates','%endblock ProjectedDensityOfStatesX')
base+=f"""DM.UseSaveDM T
LongOutput T
DFTU.PotentialShift T
DFTU.FirstIteration T
%block DFTU.Proj
 Ni1 1
 n=3 2
 {alpha:.4f} 0.00
 0.00 0.00
 Ni2 1
 n=3 2
 0.0000 0.00
 0.00 0.00
%endblock DFTU.Proj
"""
os.makedirs(name,exist_ok=True); open(f'{name}/{name}.fdf','w').write(base)
for f in ['Ni1.psml','Ni2.psml','O.psml']: shutil.copy(f,name)
shutil.copy('u0/u0.DM',f'{name}/{name}.DM'); print(name)
