#!/bin/bash
cd /opt/run/nio
for U in 0 2 4 6 8; do n=$(python3 gen.py $U); cd $n; OMP_NUM_THREADS=2 /opt/siesta/bin/siesta $n.fdf > $n.out 2>&1; cd ..; echo "$n $(grep 'Total =' $n/$n.out|tail -1) $(grep -c 'scf:' $n/$n.out)"; done
echo NIODONE
