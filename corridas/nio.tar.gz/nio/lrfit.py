import json,glob,re,sys
N0=7.581916
A={'m010':-0.1,'m005':-0.05,'p005':0.05,'p010':0.1}
res={}
for m in ('bare','scf'):
    pts=[]
    for k,a in A.items():
        f=f'/opt/run/nio/lr_{m}_{k}/lr_{m}_{k}.out'
        try: t=open(f).read()
        except: continue
        if 'Job completed' not in t: continue
        occ=[float(x.split()[-1]) for x in re.findall(r'Occupations:.*',t)[-2:]]
        pts.append({'alpha':a,'N':occ[0],'N2':occ[1]})
    res[m]=pts
def slope(p,key):
    xs=[q['alpha'] for q in p]; ys=[q[key] for q in p]; n=len(xs); mx=sum(xs)/n; my=sum(ys)/n
    return sum((x-mx)*(y-my) for x,y in zip(xs,ys))/sum((x-mx)**2 for x in xs)
out={'N0':N0,'bare':res['bare'],'scf':res['scf']}
if len(res['bare'])>=2 and len(res['scf'])>=2:
    a0,b0=slope(res['bare'],'N'),slope(res['bare'],'N2'); a,b=slope(res['scf'],'N'),slope(res['scf'],'N2')
    out.update(chi0=a0,chi=a,chi0_21=b0,chi_21=b,U=1/a0-1/a,Umat=a0/(a0*a0-b0*b0)-a/(a*a-b*b))
print(json.dumps({k:v for k,v in out.items() if k not in('bare','scf')}), res)
if '--write' in sys.argv:
    p='/mnt/project-files/DFT_App/app/dftlab/static/js/data/nio.json'; d=json.load(open(p)); d['lr']=out; json.dump(d,open(p,'w'),separators=(',',':'))
