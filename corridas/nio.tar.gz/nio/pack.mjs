import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { parseEIG, analyzeGap, parseOut, parsePDOS, groupPDOS } from '/mnt/project-files/DFT_App/app/dftlab/static/js/siesta/index.js';
const res={scan:[]};
for (const u of [0,2,4,6,8,13.8].filter(u=>existsSync(`u${u}/u${u}.PDOS`))) { const d=`u${u}`;
  const e=parseEIG(readFileSync(`${d}/${d}.EIG`,'utf8'), readFileSync(`${d}/${d}.KP`,'utf8')); const g=analyzeGap(e);
  const o=parseOut(readFileSync(`${d}/${d}.out`,'utf8')); const m=o.populations.mulliken;
  const p=parsePDOS(readFileSync(`${d}/${d}.PDOS`,'utf8')); const ef=p.fermi;
  const grp=(sp)=>groupPDOS(p,['species','l'],sp).filter(x=>/Ni1-d|O-p|Ni2-d/.test(x.label));
  const up=grp('up'), dn=grp('down'); const E=Array.from(p.energy).map(x=>+(x-ef).toFixed(3));
  const ds=a=>Array.from(a).filter((_,i)=>i%2===0).map(v=>+v.toFixed(4));
  res.scan.push({U:u, gap:g.gap, type:g.type, etot:o.final.etot, mom:m.atoms[0].Sz, nscf:o.scf.length, wall:o.timers?.wallTime,
    E:E.filter((_,i)=>i%2===0), pdos:Object.fromEntries(up.map((x,i)=>[x.label,{up:ds(x.data),dn:ds(dn[i].data)}]))});
  console.log(u, up.map(x=>x.label));
}
res.fdf=readFileSync('u4/u4.fdf','utf8');
const P='/mnt/project-files/DFT_App/app/dftlab/static/js/data/nio.json'; try{ res.lr=JSON.parse(readFileSync(P,'utf8')).lr; }catch(e){}
writeFileSync('/mnt/project-files/DFT_App/app/dftlab/static/js/data/nio.json', JSON.stringify(res));
