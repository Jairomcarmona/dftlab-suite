#!/bin/bash
cd /opt/run/nio
for m in bare scf; do for a in -0.1 -0.05 0.05 0.1; do n=$(python3 genlr.py $a $m); [ -f $n/$n.out ] && grep -q "Job completed" $n/$n.out && continue; cd $n; OMP_NUM_THREADS=2 /opt/siesta/bin/siesta $n.fdf > $n.out 2>&1; cd ..; echo "$n $(grep 'Occupations:' $n/$n.out | tail -2 | tr '\n' ' ')"; done; done
echo LRDONE
