#!/bin/bash
# Si 2x2x2 (16 atomos), LDA DZP, a = 5.396 A (minimo E(a) de eos/), desplazamientos de los 2 atomos de la base (MD.FCFirst 1, MD.FCLast 2)
export PATH=/tmp/sie/siesta/bin:$PATH
cd "$(dirname "$0")"
s=$(date +%s); OMP_NUM_THREADS=4 siesta si_fc.fdf > si_fc.out 2>&1; e=$?
echo "exit $e  wall $(( $(date +%s)-s )) s  OMP_NUM_THREADS=4" > time.txt
