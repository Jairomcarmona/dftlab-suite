import math,sys,shutil,os
PS='/mnt/project-files/DFT_App/app/dftlab/data/pseudos/lda/'
def make(name,el,Z,kind,N,vac,k=12,mesh=250,basis='DZP',a=None,c=None,smear=0.1):
    os.makedirs(name,exist_ok=True)
    shutil.copy(PS+el+'.psml',name)
    kx=ky=k
    if kind=='fcc111':
        a=a or 4.05; a_s=a/math.sqrt(2); d=a/math.sqrt(3)
        stack=[(0,0),(1/3,2/3),(2/3,1/3)]; xy=[stack[i%3] for i in range(N)]
        L=(N-1)*d+vac; lat=[(a_s,0,0),(-a_s/2,a_s*math.sqrt(3)/2,0),(0,0,L)]
    elif kind=='hcp0001':
        a_s=a or 3.209; cc=c or 5.211; d=cc/2
        stack=[(0,0),(1/3,2/3)]; xy=[stack[i%2] for i in range(N)]
        L=(N-1)*d+vac; lat=[(a_s,0,0),(-a_s/2,a_s*math.sqrt(3)/2,0),(0,0,L)]
    elif kind=='fcc100':
        a=a or 4.05; a_s=a/math.sqrt(2); d=a/2
        xy=[((0,0),(.5,.5))[i%2] for i in range(N)]
        L=(N-1)*d+vac; lat=[(a_s,0,0),(0,a_s,0),(0,0,L)]
    else:  # fcc110
        a=a or 4.05; d=a/(2*math.sqrt(2)); b=a/math.sqrt(2)
        xy=[((0,0),(.5,.5))[i%2] for i in range(N)]
        L=(N-1)*d+vac; lat=[(a,0,0),(0,b,0),(0,0,L)]
        kx=max(1,round(k*b/a)); ky=k; kx,ky=ky,kx   # long axis gets fewer k
        kx=max(1,round(k*b/a)); ky=k
    s=f"""SystemLabel {name}
XC.functional LDA
XC.authors CA
NumberOfSpecies 1
NumberOfAtoms {N}
%block ChemicalSpeciesLabel
 1 {Z} {el}
%endblock ChemicalSpeciesLabel
PAO.BasisSize {basis}
LatticeConstant 1.0 Ang
%block LatticeVectors
"""+"\n".join("%.6f %.6f %.6f"%v for v in lat)+"""
%endblock LatticeVectors
AtomicCoordinatesFormat Ang
%block AtomicCoordinatesAndAtomicSpecies
"""
    for i,(fx,fy) in enumerate(xy):
        x=fx*lat[0][0]+fy*lat[1][0]; y=fx*lat[0][1]+fy*lat[1][1]
        s+="%.6f %.6f %.6f 1\n"%(x,y,vac/2+i*d)
    s+=f"""%endblock AtomicCoordinatesAndAtomicSpecies
MeshCutoff {mesh} Ry
%block kgrid_Monkhorst_Pack
 {kx} 0 0 0.0
 0 {ky} 0 0.0
 0 0 1 0.0
%endblock kgrid_Monkhorst_Pack
ElectronicTemperature 300 K
DM.Tolerance 1.e-6
MaxSCFIterations 100
SCF.Mixer.Method Pulay
SCF.Mixer.Weight 0.3
SCF.Mixer.History 6
DM.UseSaveDM false
SaveElectrostaticPotential true
SaveTotalPotential true
SaveRho true
"""
    open(f"{name}/{name}.fdf","w").write(s)

RUNS=[('al111_n3','Al',13,'fcc111',3,18),('al111_n5','Al',13,'fcc111',5,18),('al111_n7','Al',13,'fcc111',7,18),('al111_n9','Al',13,'fcc111',9,18),
 ('al111_n5_v10','Al',13,'fcc111',5,10),('al111_n5_v26','Al',13,'fcc111',5,26),
 ('al100_n7','Al',13,'fcc100',7,18),('al110_n11','Al',13,'fcc110',11,18),
 ('mg0001_n3','Mg',12,'hcp0001',3,18),('mg0001_n5','Mg',12,'hcp0001',5,18),('mg0001_n7','Mg',12,'hcp0001',7,18),('mg0001_n9','Mg',12,'hcp0001',9,18)]
if __name__=='__main__':
    for r in RUNS: make(*r)
