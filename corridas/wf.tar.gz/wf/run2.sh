#!/bin/bash
export OMP_NUM_THREADS=2
cd /tmp/claude-0/wf
one(){ n=$1; (cd $n; s=$(date +%s); /tmp/claude-0/sie/bin/siesta $n.fdf > $n.out 2>&1; echo "$n $(( $(date +%s)-s )) s" >> ../times2.txt); }
export -f one
printf '%s\n' mg0001_n7_sz mg0001_n7_dz mg0001_n7_tzp mg0001_n7_m400 al111_n5_sz al111_n5_dz al111_n5_tzp al111_n5_m400 | xargs -P2 -I{} bash -c 'one {}'
echo DONE >> times2.txt
