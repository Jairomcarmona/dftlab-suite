#!/bin/bash
export OMP_NUM_THREADS=2
cd /tmp/claude-0/wf
one(){ n=$1; (cd $n; s=$(date +%s); /tmp/claude-0/sie/bin/siesta $n.fdf > $n.out 2>&1; echo "$n $(( $(date +%s)-s )) s" >> ../times.txt); }
export -f one
printf '%s\n' al111_n3 al111_n5 al111_n7 al111_n9 al111_n5_v10 al111_n5_v26 al100_n7 al110_n11 mg0001_n3 mg0001_n5 mg0001_n7 mg0001_n9 | xargs -P2 -I{} bash -c 'one {}'
echo DONE >> times.txt
