#!/bin/bash
export OMP_NUM_THREADS=2
cd /tmp/claude-0/wf
one(){ n=$1; (cd $n; s=$(date +%s); /tmp/claude-0/sie/bin/siesta $n.fdf > $n.out 2>&1; echo "$n $(( $(date +%s)-s )) s" >> ../times4.txt); }
export -f one
printf '%s\n' mg0001_n7_es5 mg0001_n7_es1 al111_n5_es5 al111_n5_es1 | xargs -P2 -I{} bash -c 'one {}'
echo DONE >> times4.txt
