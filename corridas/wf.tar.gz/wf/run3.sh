#!/bin/bash
export OMP_NUM_THREADS=2
cd /tmp/claude-0/wf
one(){ n=$1; (cd $n; s=$(date +%s); /tmp/claude-0/sie/bin/siesta $n.fdf > $n.out 2>&1; echo "$n $(( $(date +%s)-s )) s" >> ../times3.txt); }
export -f one
printf '%s\n' al110_n11_alda al111_n9_alda al100_n7_alda al111_n5_alda | xargs -P2 -I{} bash -c 'one {}'
echo DONE >> times3.txt
