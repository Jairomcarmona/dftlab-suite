import sys,random
a=5.396
base=[(0,0,0),(0,.5,.5),(.5,0,.5),(.5,.5,0)]
at=[]
for i in range(2):
 for j in range(2):
  for k in range(2):
   for f in base:
    for s in (0,.25):
     at.append(((i+f[0]+s)/2,(j+f[1]+s)/2,(k+f[2]+s)/2))
def fdf(label,atoms,kg,extra=''):
  L=2*a
  s=f"""SystemLabel {label}
XC.functional LDA
XC.authors CA
PAO.BasisSize DZP
MeshCutoff 300 Ry
DM.Tolerance 1.e-5
SolutionMethod diagon
NumberOfSpecies 1
NumberOfAtoms {len(atoms)}
%block ChemicalSpeciesLabel
 1 14 Si
%endblock ChemicalSpeciesLabel
LatticeConstant 1.0 Ang
%block LatticeVectors
{L:.6f} 0 0
0 {L:.6f} 0
0 0 {L:.6f}
%endblock LatticeVectors
AtomicCoordinatesFormat Fractional
%block AtomicCoordinatesAndAtomicSpecies
"""+"".join(f"{x:.6f} {y:.6f} {z:.6f} 1\n" for x,y,z in atoms)+f"""%endblock AtomicCoordinatesAndAtomicSpecies
%block kgrid_Monkhorst_Pack
 {kg} 0 0 0.5
 0 {kg} 0 0.5
 0 0 {kg} 0.5
%endblock kgrid_Monkhorst_Pack
{extra}"""
  return s
import os
os.makedirs('vac',exist_ok=True)
open('vac/bulk64.fdf','w').write(fdf('bulk64',at,2))
# vacancy: remove atom 0 at origin; its 4 neighbours at (1/8,1/8,1/8)-type images
vac=at[1:]
open('vac/vac_unrel.fdf','w').write(fdf('vac_unrel',vac,2))
