import math,os
exec(open('genh2o.py').read().split("os.makedirs")[0])
os.makedirs('hf',exist_ok=True)
r0=0.9572; ang=104.52
def g1(r,shift=0.0):
  t=math.radians(ang)/2
  P=[(5.0,5.0,5.0),(5+r*math.sin(t),5+r*math.cos(t),5.0),(5-r0*math.sin(t),5+r0*math.cos(t),5.0)]
  return [(x+shift,y,z) for x,y,z in P]
rs=[round(0.85+0.025*i,3) for i in range(13)]
for tag,b,m in (('dzp300','DZP',300),('dzp60','DZP',60),('sz300','SZ',300)):
  for r in rs:
    open(f'hf/{tag}_r{r:.3f}.fdf','w').write(h2o(f'{tag}_r{r:.3f}',g1(r),basis=b,mesh=m,tol='1.e-6'))
for m in (60,300):
  for i in range(11):
    s=round(0.02*i,3)
    open(f'hf/egg{m}_s{s:.3f}.fdf','w').write(h2o(f'egg{m}_s{s:.3f}',g1(1.05,s),mesh=m,tol='1.e-6'))
for e in range(1,8):
  open(f'hf/tol_1e-{e}.fdf','w').write(h2o(f'tol_1e-{e}',g1(1.05),tol=f'1.e-{e}'))
print(len(os.listdir('hf')))
