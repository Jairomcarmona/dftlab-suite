#!/bin/bash
export PATH=/tmp/sie/siesta/bin:$PATH OMP_NUM_THREADS=3
cd /tmp/w/fz/vac
while pgrep -f "siesta bulk64.fdf" >/dev/null; do sleep 10; done
for f in vac_unrel vac_relax; do [ -s $f.out ] && grep -q "End of run" $f.out && continue
  t0=$(date +%s); siesta $f.fdf > $f.out; echo "$f wall $(( $(date +%s)-t0 ))" >> time.txt; done
echo VAC_DONE
