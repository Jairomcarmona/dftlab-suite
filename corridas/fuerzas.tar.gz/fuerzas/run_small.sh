#!/bin/bash
export PATH=/tmp/sie/siesta/bin:$PATH OMP_NUM_THREADS=1
cd /tmp/w/fz
for d in h2o hf eos; do cd $d; cp ../*.psml ../Si.psf . 2>/dev/null
  for f in *.fdf; do o=${f%.fdf}.out; [ -s $o ] && grep -q "End of run" $o && continue
    t0=$(date +%s.%N); siesta $f > $o; echo "$f wall $(echo "$(date +%s.%N)-$t0"|bc)" >> time.txt; done; cd ..; done
echo SMALL_DONE
