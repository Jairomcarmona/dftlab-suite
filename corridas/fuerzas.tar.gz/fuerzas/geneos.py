import os
def si2(label,a,basis='DZP',mesh=300,extra='',pos=((0.0,0.0,0.0),(0.25,0.25,0.25))):
  h=a/2
  return f"""SystemLabel {label}
XC.functional LDA
XC.authors CA
PAO.BasisSize {basis}
MeshCutoff {mesh} Ry
DM.Tolerance 1.e-6
SolutionMethod diagon
NumberOfSpecies 1
NumberOfAtoms 2
%block ChemicalSpeciesLabel
 1 14 Si
%endblock ChemicalSpeciesLabel
LatticeConstant 1.0 Ang
%block LatticeVectors
0.0 {h:.6f} {h:.6f}
{h:.6f} 0.0 {h:.6f}
{h:.6f} {h:.6f} 0.0
%endblock LatticeVectors
AtomicCoordinatesFormat Fractional
%block AtomicCoordinatesAndAtomicSpecies
"""+"".join(f"{x:.6f} {y:.6f} {z:.6f} 1\n" for x,y,z in pos)+f"""%endblock AtomicCoordinatesAndAtomicSpecies
%block kgrid_Monkhorst_Pack
 8 0 0 0.5
 0 8 0 0.5
 0 0 8 0.5
%endblock kgrid_Monkhorst_Pack
{extra}"""
os.makedirs('eos',exist_ok=True)
avals=[round(5.25+0.03*i,2) for i in range(11)]
for tag,b,m in (('dzp300','DZP',300),('dzp100','DZP',100),('sz300','SZ',300)):
  for a in avals:
    open(f'eos/{tag}_a{a:.2f}.fdf','w').write(si2(f'{tag}_a{a:.2f}',a,b,m))
open('eos/vc_cg.fdf','w').write(si2('vc_cg',5.60,extra="""MD.TypeOfRun CG
MD.VariableCell true
MD.Steps 100
MD.MaxForceTol 0.01 eV/Ang
MD.MaxStressTol 0.05 GPa
"""))
print(avals)
