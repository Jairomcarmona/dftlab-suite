import math,os
def h2o(label,pos,extra='',basis='DZP',mesh=300,tol='1.e-5'):
  return f"""SystemLabel {label}
XC.functional LDA
XC.authors CA
PAO.BasisSize {basis}
MeshCutoff {mesh} Ry
DM.Tolerance {tol}
SolutionMethod diagon
NumberOfSpecies 2
NumberOfAtoms 3
%block ChemicalSpeciesLabel
 1 8 O
 2 1 H
%endblock ChemicalSpeciesLabel
LatticeConstant 1.0 Ang
%block LatticeVectors
10 0 0
0 10 0
0 0 10
%endblock LatticeVectors
AtomicCoordinatesFormat Ang
%block AtomicCoordinatesAndAtomicSpecies
"""+"".join(f"{x:.6f} {y:.6f} {z:.6f} {s}\n" for (x,y,z),s in zip(pos,(1,2,2)))+"%endblock AtomicCoordinatesAndAtomicSpecies\n"+extra
def geom(r1,r2,ang):
  t=math.radians(ang)/2
  O=(5.0,5.0,5.0)
  return [O,(5+r1*math.sin(t),5+r1*math.cos(t),5.0),(5-r2*math.sin(t),5+r2*math.cos(t),5.0)]
os.makedirs('h2o',exist_ok=True)
start=geom(1.08,0.92,125.0)
for m in ('CG','Broyden','FIRE'):
  open(f'h2o/relax_{m.lower()}.fdf','w').write(h2o(f'relax_{m.lower()}',start,f"""MD.TypeOfRun {m}
MD.Steps 300
MD.MaxForceTol 0.01 eV/Ang
WriteCoorStep true
WriteForces true
"""))
