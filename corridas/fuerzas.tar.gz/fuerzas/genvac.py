import random,re
random.seed(7)
src=open('vac/vac_unrel.fdf').read()
lines=src.split('\n'); i0=lines.index('%block AtomicCoordinatesAndAtomicSpecies')+1
L=2*5.396; nb=[]
for i in range(i0,i0+63):
  x,y,z,s=lines[i].split(); f=[float(x),float(y),float(z)]
  d=sum((min(abs(v),1-abs(v))*L)**2 for v in f)**.5
  if d<2.5:
    nb.append(i-i0)
    f=[v+random.uniform(-0.02,0.02)/L for v in f]
    lines[i]=f"{f[0]:.6f} {f[1]:.6f} {f[2]:.6f} 1"
print('neighbours',nb)
out='\n'.join(lines).replace('SystemLabel vac_unrel','SystemLabel vac_relax')+"""MD.TypeOfRun CG
MD.Steps 80
MD.MaxForceTol 0.02 eV/Ang
WriteCoorStep true
"""
open('vac/vac_relax.fdf','w').write(out)
