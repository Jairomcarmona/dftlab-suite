#!/bin/bash
# job.sh <dir> <name>
cd $1 && OMP_NUM_THREADS=1 /opt/siesta/bin/siesta $2.fdf > $2.out 2>&1; echo done $2 >> /tmp/w/mag/progress.log
