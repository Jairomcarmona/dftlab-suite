import sys,os
# uso: genfe.py <a> <fm|nm> [bands] -> escribe carpeta y devuelve nombre
a=float(sys.argv[1]); mode=sys.argv[2]; extra=sys.argv[3] if len(sys.argv)>3 else ''
name=f"fe_{mode}_{a:.3f}"+('_'+extra if extra else '')
h=a/2
s=f"""SystemLabel {name}
XC.functional GGA
XC.authors PBE
NumberOfSpecies 1
NumberOfAtoms 1
%block ChemicalSpeciesLabel
 1 26 Fe
%endblock ChemicalSpeciesLabel
PAO.BasisSize DZP
PAO.EnergyShift 50 meV
LatticeConstant 1.0 Ang
%block LatticeVectors
{-h:.6f} {h:.6f} {h:.6f}
{h:.6f} {-h:.6f} {h:.6f}
{h:.6f} {h:.6f} {-h:.6f}
%endblock LatticeVectors
AtomicCoordinatesFormat Fractional
%block AtomicCoordinatesAndAtomicSpecies
0.0 0.0 0.0 1
%endblock AtomicCoordinatesAndAtomicSpecies
MeshCutoff 300 Ry
%block kgrid_Monkhorst_Pack
 16 0 0 0.0
 0 16 0 0.0
 0 0 16 0.0
%endblock kgrid_Monkhorst_Pack
OccupationFunction MP
OccupationMPOrder 1
ElectronicTemperature 1160 K
SCF.Mixer.Method Pulay
SCF.Mixer.Weight 0.1
SCF.Mixer.History 8
MaxSCFIterations 300
SCF.DM.Tolerance 1.e-5
WriteMullikenPop 1
WriteEigenvalues T
"""
if mode=='fm':
    s+="Spin polarized\n%block DM.InitSpin\n 1 +\n%endblock DM.InitSpin\n"
if extra=='pdos':
    s+="""%block ProjectedDensityOfStates
 -12.0 8.0 0.08 1000 eV
%endblock ProjectedDensityOfStates
%block PDOS.kgrid_Monkhorst_Pack
 24 0 0 0.0
 0 24 0 0.0
 0 0 24 0.0
%endblock PDOS.kgrid_Monkhorst_Pack
"""
os.makedirs(name,exist_ok=True)
open(f"{name}/{name}.fdf","w").write(s)
os.system(f"cp Fe.psml {name}/ 2>/dev/null || cp fe/Fe.psml {name}/")
print(name)
