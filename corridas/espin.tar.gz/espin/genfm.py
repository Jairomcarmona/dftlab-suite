import os,sys
U=float(sys.argv[1]); name=f'fm_u{U:g}'
a=4.17
s=f"""SystemLabel {name}
XC.functional GGA
XC.authors PBE
NumberOfSpecies 3
NumberOfAtoms 4
%block ChemicalSpeciesLabel
 1 28 Ni1
 2 28 Ni2
 3 8 O
%endblock ChemicalSpeciesLabel
PAO.BasisSize DZP
PAO.EnergyShift 50 meV
LatticeConstant 1.0 Ang
%block LatticeVectors
{a:.6f} {a/2:.6f} {a/2:.6f}
{a/2:.6f} {a:.6f} {a/2:.6f}
{a/2:.6f} {a/2:.6f} {a:.6f}
%endblock LatticeVectors
AtomicCoordinatesFormat Fractional
%block AtomicCoordinatesAndAtomicSpecies
0.00 0.00 0.00 1
0.50 0.50 0.50 2
0.25 0.25 0.25 3
0.75 0.75 0.75 3
%endblock AtomicCoordinatesAndAtomicSpecies
MeshCutoff 300 Ry
%block kgrid_Monkhorst_Pack
 6 0 0 0.0
 0 6 0 0.0
 0 0 6 0.0
%endblock kgrid_Monkhorst_Pack
Spin polarized
%block DM.InitSpin
 1 +
 2 +
%endblock DM.InitSpin
ElectronicTemperature 100 K
SCF.Mixer.Method Pulay
SCF.Mixer.Weight 0.1
SCF.Mixer.History 8
MaxSCFIterations 300
SCF.DM.Tolerance 1.e-4
WriteMullikenPop 1
WriteEigenvalues T
%block ProjectedDensityOfStates
 -12.0 6.0 0.08 1800 eV
%endblock ProjectedDensityOfStates
%block PDOS.kgrid_Monkhorst_Pack
 12 0 0 0.0
 0 12 0 0.0
 0 0 12 0.0
%endblock PDOS.kgrid_Monkhorst_Pack
"""
if U>0:
    s+=f"""%block DFTU.Proj
 Ni1 1
 n=3 2
 {U:.2f} 0.00
 0.00 0.00
 Ni2 1
 n=3 2
 {U:.2f} 0.00
 0.00 0.00
%endblock DFTU.Proj
"""
os.makedirs(name,exist_ok=True); open(f'{name}/{name}.fdf','w').write(s)
os.system(f'cp Ni1.psml Ni2.psml O.psml {name}/'); print(name)
