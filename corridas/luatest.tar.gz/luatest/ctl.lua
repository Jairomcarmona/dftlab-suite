-- DFT Lab live SCF hook: streams each SCF iteration as JSON and reads control.txt for live changes
local Ry=13.605693122994
local names={"E.total","E.fermi","E.kinetic","E.harris","E.band_structure","E.exchange_correlation","E.electrostatic","E.neutral_atom","E.ions","E.free","SCF.dD","SCF.dH","SCF.dE","SCF.iteration","SCF.Mixer.Weight","geom.orbital_charge"}
local function num(x) if x==nil then return "null" end return string.format("%.10g",x) end
function siesta_comm()
  if siesta.state == siesta.SCF_LOOP then
    siesta.receive(names)
    local E=siesta.E
    local q={}
    if siesta.geom.orbital_charge then for i,v in ipairs(siesta.geom.orbital_charge) do q[#q+1]=num(v) end end
    local f=io.open("live.jsonl","a")
    f:write(string.format('{"it":%d,"Etot":%s,"Eharris":%s,"Efree":%s,"EF":%s,"Ekin":%s,"Ebs":%s,"Exc":%s,"Eel":%s,"Ena":%s,"Eions":%s,"dD":%s,"dH":%s,"dE":%s,"w":%s,"q":[%s]}\n',
      siesta.SCF.iteration or -1, num(E.total and E.total*Ry), num(E.harris and E.harris*Ry), num(E.free and E.free*Ry), num(E.fermi and E.fermi*Ry), num(E.kinetic and E.kinetic*Ry),
      num(E.band_structure and E.band_structure*Ry), num(E.exchange_correlation and E.exchange_correlation*Ry), num(E.electrostatic and E.electrostatic*Ry), num(E.neutral_atom and E.neutral_atom*Ry), num(E.ions and E.ions*Ry),
      num(siesta.SCF.dD), num(siesta.SCF.dH and siesta.SCF.dH*Ry), num(siesta.SCF.dE and siesta.SCF.dE*Ry), num(siesta.SCF.Mixer.Weight), table.concat(q,",")))
    f:close()
    local c=io.open("control.txt","r")
    if c then local w=tonumber(c:read("*l")); c:close(); os.remove("control.txt"); if w then siesta.SCF.Mixer.Weight=w; siesta.send({"SCF.Mixer.Weight"}) end end
  end
end
