#!/bin/bash
cd /opt/run/dens
(cd si && OMP_NUM_THREADS=2 /opt/siesta/bin/siesta si.fdf > si.out 2>&1) &
(cd h2o && OMP_NUM_THREADS=2 /opt/siesta/bin/siesta h2o.fdf > h2o.out 2>&1) &
wait
(cd mgo && OMP_NUM_THREADS=4 /opt/siesta/bin/siesta mgo.fdf > mgo.out 2>&1)
echo DENSDONE
