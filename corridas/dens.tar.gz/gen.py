import os,shutil,sys
LIB='/mnt/project-files/DFT_App/app/dftlab/data/pseudos/pbe'
common="""XC.functional GGA
XC.authors PBE
PAO.BasisSize DZP
PAO.EnergyShift 30 meV
MeshCutoff 300 Ry
SCF.Mixer.Method Pulay
SCF.Mixer.Weight 0.25
SCF.Mixer.History 6
MaxSCFIterations 100
SCF.DM.Tolerance 1e-5
SaveRho T
SaveDeltaRho T
WriteMullikenPop 1
WriteHirshfeldPop T
WriteVoronoiPop T
"""
def cart(a,atoms):
    return "\n".join(f"{x*a:.6f} {y*a:.6f} {z*a:.6f} {s}" for s,(x,y,z) in atoms)
sys_={}
a=5.431; base=[(0,0,0),(0,.5,.5),(.5,0,.5),(.5,.5,0)]
si=[(1,b) for b in base]+[(1,(b[0]+.25,b[1]+.25,b[2]+.25)) for b in base]
sys_['si']=dict(species={'Si':14},lat=a,cell=[(1,0,0),(0,1,0),(0,0,1)],atoms=[('Si',p) for _,p in si],k=6,extra="")
a=4.212
mg=[('Mg',b) for b in base]+[('O',(b[0]+.5,b[1],b[2])) for b in base]
sys_['mgo']=dict(species={'Mg':12,'O':8},lat=a,cell=[(1,0,0),(0,1,0),(0,0,1)],atoms=mg,k=6,extra="")
import math
d=0.9572; ang=104.52*math.pi/180; L=10.0
h=[(0.5,0.5,0.5),(0.5+d*math.sin(ang/2)/L,0.5,0.5+d*math.cos(ang/2)/L),(0.5-d*math.sin(ang/2)/L,0.5,0.5+d*math.cos(ang/2)/L)]
sys_['h2o']=dict(species={'O':8,'H':1},lat=L,cell=[(1,0,0),(0,1,0),(0,0,1)],atoms=[('O',h[0]),('H',h[1]),('H',h[2])],k=1,extra="")
for name,s in sys_.items():
    os.makedirs(name,exist_ok=True)
    sp=list(s['species']); 
    f=f"SystemLabel {name}\nNumberOfAtoms {len(s['atoms'])}\nNumberOfSpecies {len(sp)}\n%block ChemicalSpeciesLabel\n"+"".join(f" {i+1} {s['species'][e]} {e}\n" for i,e in enumerate(sp))+"%endblock ChemicalSpeciesLabel\n"
    f+=f"LatticeConstant {s['lat']} Ang\n%block LatticeVectors\n"+"".join(" %g %g %g\n"%v for v in s['cell'])+"%endblock LatticeVectors\nAtomicCoordinatesFormat Fractional\n%block AtomicCoordinatesAndAtomicSpecies\n"
    f+="".join(f"{x:.6f} {y:.6f} {z:.6f} {sp.index(e)+1}\n" for e,(x,y,z) in s['atoms'])+"%endblock AtomicCoordinatesAndAtomicSpecies\n"
    k=s['k']; f+=f"%block kgrid_Monkhorst_Pack\n {k} 0 0 0.0\n 0 {k} 0 0.0\n 0 0 {k} 0.0\n%endblock kgrid_Monkhorst_Pack\n" if k>1 else ""
    if name=='h2o': f+="DM.Tolerance 1e-5\n"
    f+=common
    open(f'{name}/{name}.fdf','w').write(f)
    for e in sp: shutil.copy(f'{LIB}/{e}.psml',f'{name}/{e}.psml')
