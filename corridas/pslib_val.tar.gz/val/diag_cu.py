import sys; sys.path.insert(0,'/opt/run/pslib/val'); import val
A={'lda':[3.47,3.52,3.57],'pbe':[3.58,3.63,3.68]}
for xc in ('lda','pbe'):
    for tag,extra,ps in [('_tzp',['PAO.BasisSize TZP','PAO.EnergyShift 50 meV'],None),('_shipped',[],'/opt/run/pslib/alt/cu_shipped/'+xc),('_es20',['PAO.EnergyShift 20 meV'],None)]:
        ex=list(extra)
        if 'PAO.EnergyShift 50 meV' in ex or 'PAO.EnergyShift 20 meV' in ex: pass
        r=val.run('Cu',xc,400,tag=tag,extra=ex,psdir=ps,abs_a=A[xc])
        print('DIAG',xc,tag,'a0=%.4f B0=%.1f'%(r['a0'],r['B0_GPa']),flush=True)
