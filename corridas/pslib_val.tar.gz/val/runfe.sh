#!/bin/bash
while ! grep -q VALDONE /tmp/claude-0/-home-claude/d87ddaff-ef85-5955-9e4b-2e2775a6c709/tasks/bldo63trn.output; do sleep 30; done
cd /opt/run/pslib/val && python3 fetest.py
