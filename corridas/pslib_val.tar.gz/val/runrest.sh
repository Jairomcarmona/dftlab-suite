#!/bin/bash
cd /opt/run/pslib/val
for m in Si C Al MgO GaAs NaCl ZnO; do for x in lda pbe; do [ -f res/${m}_${x}.json ] && continue; python3 val.py $m $x 400 2>&1 | grep RESULT; done; done
echo VALDONE
