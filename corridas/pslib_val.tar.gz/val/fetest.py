import json,sys
sys.argv=['x']; exec(open('val.py').read().split('if __name__')[0])
R={}
R['fe_lo']=run('Fe','pbe',abs_a=[2.74,2.77,2.79],tag='_lo')
R['fe_tzp']=run('Fe','pbe',abs_a=[2.79,2.83,2.87],tag='_tzp',extra=('PAO.BasisSize TZP','PAO.EnergyShift 5 meV'))
R['ni_tight']=run('Ni','pbe',tag='_tight',extra=('DM.Tolerance 1e-6','SCF.H.Tolerance 1e-5 eV'))
json.dump(R,open('fetest.json','w'),indent=1)
print('FETESTDONE')
