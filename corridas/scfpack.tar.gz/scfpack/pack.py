import re,json,glob,os
num=re.compile(r'-?\d+\.\d{6}')
def fdfval(t,key):
    m=re.search(r'^\s*'+re.escape(key)+r'\s+(\S+)',t,re.M|re.I); return m.group(1) if m else None
def parse(d,sys):
    out=glob.glob(d+'/*.out')[0]; t=open(out).read()
    fdf=open(glob.glob(os.path.dirname(d)+'/'+os.path.basename(d)[2:]+'.fdf')[0]).read()
    it=[]
    for line in t.splitlines():
        if line.strip().startswith('scf:') and re.match(r'\s*scf:\s+\d',line):
            n=int(line.split()[1]); v=[float(x) for x in num.findall(line[12:])]
            if len(v)>=6: it.append([n]+v[:6])
    fin={}
    m=re.search(r'Final energy \(eV\):(.*?)\n\s*\n',t,re.S)
    if m:
        for l in m.group(1).splitlines():
            mm=re.match(r'siesta:\s+(.+?)\s+=\s+(-?\d+\.\d+)',l)
            if mm: fin[mm.group(1).strip()]=float(mm.group(2))
    conv='SCF Convergence by' in t or 'SCF cycle converged' in t or ('scf: iscf' not in t and 'Job completed' in t and len(it)<int(fdfval(fdf,'MaxSCFIterations') or 1000))
    crashed='Error' in t[-3000:] or 'Backtrace' in t[-5000:] or '#0 ' in t[-5000:]
    return dict(id=os.path.basename(d)[2:],system=sys,method=fdfval(fdf,'SCF.Mixer.Method') or 'Pulay',weight=float(fdfval(fdf,'SCF.Mixer.Weight') or 0.25),
        history=int(fdfval(fdf,'SCF.Mixer.History') or 2),mix=('DM' if re.search(r'SCF.Mix\s+density',fdf,re.I) or 'MixHamiltonian F' in fdf or re.search(r'SCF\.Mix\s+DM',fdf,re.I) else 'H'),
        temp=fdfval(fdf,'ElectronicTemperature'),maxit=int(fdfval(fdf,'MaxSCFIterations') or 1000),
        cols=['it','Eharris','Etot','Efree','dDmax','Ef','dHmax'],iters=it,final=fin,converged=bool(conv and not crashed and len(it)<int(fdfval(fdf,'MaxSCFIterations') or 1000)),fdf=fdf)
runs=[parse(d,'Si (diamante, 2 át.)') for d in sorted(glob.glob('/opt/run/scf/r_*'))]+[parse(d,'Mg (slab fcc, 16 át.)') for d in sorted(glob.glob('/opt/run/mg/r_*'))]
lua=[json.loads(l) for l in open('/opt/run/luatest/live.jsonl')]
for r in runs: print(r['id'],r['method'],r['weight'],r['mix'],len(r['iters']),r['converged'],list(r['final'])[:3])
json.dump(dict(runs=runs,lua=lua),open('/mnt/project-files/DFT_App/app/dftlab/static/js/data/scf_runs.json','w'))
