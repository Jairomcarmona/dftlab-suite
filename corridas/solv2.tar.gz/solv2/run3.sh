#!/bin/bash
cd /opt/run/solv2
while ! grep -q SOLV2DONE /tmp/claude-0/-home-claude/d87ddaff-ef85-5955-9e4b-2e2775a6c709/tasks/bzr09fon8.output; do sleep 30; done
ef=$(grep "Fermi =" diag_2/diag_2.out | tail -1 | awk '{print $4}')
for rc in 5 6 7; do n=$(python3 gen.py ordern 2 $ef $rc); cd $n; t0=$(date +%s.%N); OMP_NUM_THREADS=2 /opt/siesta/bin/siesta $n.fdf > $n.out 2>&1; echo "$(echo "$(date +%s.%N) - $t0" | bc) s" > time.txt; cd ..; echo "$n $(cat $n/time.txt) $(grep 'Total =' $n/$n.out | tail -1)"; done
echo SOLV3DONE
