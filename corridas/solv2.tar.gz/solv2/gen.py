import os,sys
a=5.431
basis=[(0,0,0),(0,.5,.5),(.5,0,.5),(.5,.5,0)]
def cell(n):
    at=[]
    for i in range(n):
        for j in range(n):
            for k in range(n):
                for b in basis:
                    for d in [(0,0,0),(.25,.25,.25)]:
                        at.append(((i+b[0]+d[0])*a,(j+b[1]+d[1])*a,(k+b[2]+d[2])*a))
    return at
def mk(n,solver,eta=None,rc=4.0):
    name=f'{solver}_{n}' if rc==4.0 else f'onrc{rc:g}_{n}'; at=cell(n); L=n*a
    s=f"""SystemLabel {name}
XC.functional LDA
XC.authors CA
NumberOfSpecies 1
NumberOfAtoms {len(at)}
%block ChemicalSpeciesLabel
 1 14 Si
%endblock ChemicalSpeciesLabel
PAO.BasisSize SZ
LatticeConstant 1.0 Ang
%block LatticeVectors
{L:.6f} 0 0
0 {L:.6f} 0
0 0 {L:.6f}
%endblock LatticeVectors
AtomicCoordinatesFormat Ang
%block AtomicCoordinatesAndAtomicSpecies
"""+''.join(f"{x:.6f} {y:.6f} {z:.6f} 1\n" for x,y,z in at)+"""%endblock AtomicCoordinatesAndAtomicSpecies
MeshCutoff 100 Ry
MaxSCFIterations 100
DM.Tolerance 1.e-4
SCF.Mixer.Method Pulay
SCF.Mixer.Weight 0.25
SCF.Mixer.History 6
WriteDM F
"""
    if solver=='diag': s+="SolutionMethod diagon\n"
    if solver=='omm': s+="SolutionMethod OMM\nOMM.Precon -1\nON.eta 0.0 eV\n"
    if solver=='ordern': s+=f"SolutionMethod OrderN\nON.Functional Kim\nON.eta {eta:.3f} eV\nON.RcLWF {rc:.1f} Ang\nON.MaxNumIter 1000\nON.Etol 1.e-8\n"
    os.makedirs(name,exist_ok=True); open(f'{name}/{name}.fdf','w').write(s); os.system(f'cp Si.psf {name}/')
    return name
if __name__=='__main__':
    solver=sys.argv[1]; eta=float(sys.argv[3]) if len(sys.argv)>3 else None
    rc=float(sys.argv[4]) if len(sys.argv)>4 else 4.0
    print(mk(int(sys.argv[2]),solver,eta,rc))
