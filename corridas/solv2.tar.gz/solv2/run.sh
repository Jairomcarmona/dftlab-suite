#!/bin/bash
cd /opt/run/solv2
run(){ n=$(python3 gen.py "$@"); cd $n; t0=$(date +%s.%N); OMP_NUM_THREADS=2 /opt/siesta/bin/siesta $n.fdf > $n.out 2>&1; echo "$(echo "$(date +%s.%N) - $t0" | bc) s" > time.txt; cd ..; echo "$n $(cat $n/time.txt) $(grep 'Total =' $n/$n.out | tail -1)"; }
for n in 1 2 3 4; do run diag $n; done
for n in 1 2 3 4; do ef=$(grep "Fermi =" diag_$n/diag_$n.out | tail -1 | awk '{print $4}'); run ordern $n $ef; done
for n in 1 2 3; do run omm $n; done
echo SOLVDONE
