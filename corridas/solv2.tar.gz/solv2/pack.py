import json,re,os,glob
out=[]
for d in sorted(glob.glob('/opt/run/solv2/*_[0-9]')):
    n=os.path.basename(d); s,k=n.split('_'); k=int(k); rc=None
    if s.startswith('onrc'): rc=float(s[4:])
    elif s=='ordern': rc=4.0
    f=f'{d}/{n}.out'
    if not os.path.exists(f) or 'Job completed' not in open(f).read(): continue
    t=open(f).read()
    E=float(re.findall(r'siesta:\s+Total =\s+(-?[\d.]+)',t)[-1])
    clk=[float(x) for x in re.findall(r'end of scf step\s+([\d.]+)',open(f'{d}/CLOCK').read())]
    tot=float(open(f'{d}/time.txt').read().split()[0])
    cg=[]
    if rc:
        for blk in t.split('ordern: enum')[1:]: cg.append(len(re.findall(r'cgwf: iter',blk)))
    out.append(dict(solver='ordern' if rc else s,n=k,nat=8*k**3,time=round(tot,3),etot=E,nscf=len(clk),clock=[round(c,3) for c in clk],cg=cg,rc=rc))
ref={r['nat']:r['etot'] for r in out if r['solver']=='diag'}
for r in out:
    if r['nat'] in ref: r['dE_meV']=round((r['etot']-ref[r['nat']])/r['nat']*1000,4)
json.dump({'runs':out,'meta':'Si diamante, SZ, LDA, Γ, MeshCutoff 100 Ry, 2 hilos OpenMP, SIESTA 5.4.2'},open('/mnt/project-files/DFT_App/app/dftlab/static/js/data/solvers.json','w'),separators=(',',':'))
for r in out: print(r['solver'],r['nat'],r['time'],r['nscf'],r.get('dE_meV'),r['cg'][:8])
