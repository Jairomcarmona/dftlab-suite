#!/bin/bash
cd /opt/run/solv2
run(){ n=$(python3 gen.py "$@"); cd $n; t0=$(date +%s.%N); OMP_NUM_THREADS=2 /opt/siesta/bin/siesta $n.fdf > $n.out 2>&1; echo "$(echo "$(date +%s.%N) - $t0" | bc) s" > time.txt; cd ..; echo "$n $(cat $n/time.txt) $(grep 'Total =' $n/$n.out | tail -1)"; }
run omm 4; run diag 5; run omm 5
echo SOLV2DONE
