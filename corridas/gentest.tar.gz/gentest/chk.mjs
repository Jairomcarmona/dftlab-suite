import { readFileSync } from 'node:fs';
import { parseBands, bandEdges, parseOut } from '/mnt/project-files/DFT_App/app/dftlab/static/js/siesta/index.js';
const b=parseBands(readFileSync('si.bands','utf8')); const e=bandEdges(b);
console.log(b.labels.map(l=>l.label+'@'+l.x.toFixed(3)).join(' '), 'gap',e.gap.toFixed(3),'vbm x',e.vbm.x.toFixed(3),'cbm x',e.cbm.x.toFixed(3));
const o=parseOut(readFileSync('si.out','utf8')); console.log(o.kgrid?.supercell, o.mesh, o.final);
