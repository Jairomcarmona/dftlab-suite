import { siestaInput, jobScript } from '/mnt/project-files/DFT_App/app/dftlab/static/js/tools/fdfgen.js';
import { initMoyo } from '/mnt/project-files/DFT_App/app/dftlab/static/js/crystal/moyo/loader.js';
import { getPathOrigCell } from '/mnt/project-files/DFT_App/app/dftlab/static/js/crystal/kpath.js';
import { writeFileSync } from 'node:fs';
await initMoyo();
const a=5.431, cell={lattice:[[0,a/2,a/2],[a/2,0,a/2],[a/2,a/2,0]],positions:[[0,0,0],[.25,.25,.25]],numbers:[14,14]};
const path=getPathOrigCell(cell,{symprec:1e-3});
writeFileSync('si.fdf', siestaInput(cell,{label:'si',xc:'LDA',mesh:150,kspacing:0.25,optical:true,lua:false,saveHS:true},path));
writeFileSync('run.sh', jobScript('si',[14],{sched:'local',ntasks:1,omp:2,modules:'',siesta:'/opt/siesta/bin/siesta'}));
