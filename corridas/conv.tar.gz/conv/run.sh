#!/bin/bash
cd /opt/run/conv
cat jobs.txt | xargs -P 2 -I{} bash -c 'cd {} && [ -f {}.out ] && grep -q "Job completed" {}.out || OMP_NUM_THREADS=1 /opt/siesta/bin/siesta {}.fdf > {}.out 2>&1'
echo CONVDONE
