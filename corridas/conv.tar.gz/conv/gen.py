import os,sys
T=open('/opt/run/luatest/si.fdf').read().replace('LUA.Script ctl.lua\n','')
def mk(name,a=5.431,basis='DZP',mesh=200,k=6,shift=None,dx=0.0,extra=''):
    h=a/2
    s=T.replace('SystemLabel silua','SystemLabel '+name).replace('PAO.BasisSize DZP','PAO.BasisSize '+basis)
    s=s.replace('2.71550000','%.8f'%h).replace('MeshCutoff 200 Ry','MeshCutoff %g Ry'%mesh)
    s=s.replace(' 6 0 0 0.5',' %d 0 0 0.5'%k).replace(' 0 6 0 0.5',' 0 %d 0 0.5'%k).replace(' 0 0 6 0.5',' 0 0 %d 0.5'%k)
    s=s.replace('SCF.Mixer.Method linear','SCF.Mixer.Method Pulay').replace('DM.Tolerance 1.e-5','DM.Tolerance 1.e-5\nWriteEigenvalues T')
    if shift is not None: s+='PAO.EnergyShift %g meV\n'%shift
    if dx:
        s=s.replace('AtomicCoordinatesFormat Fractional','AtomicCoordinatesFormat Ang').replace('0.00000000 0.00000000 0.00000000 1','%.6f 0.0 0.0 1'%dx).replace('1.25000000 0.25000000 0.25000000 1','%.6f %.6f %.6f 1'%(a/4+dx,a/4,a/4))
    elif 'Ang' not in s.split('AtomicCoordinatesFormat')[1][:6]:
        pass
    s+=extra
    os.makedirs(name,exist_ok=True); open(name+'/'+name+'.fdf','w').write(s); os.system('cp Si.psf '+name+'/')
    return name
jobs=[]
for m in [40,60,80,100,125,150,200,250,300,400,500,600]: jobs.append(mk('mesh_%d'%m,mesh=m))
for m in [100,300]:
    # egg-box: mesh spacing along x for fcc cell; translate over 1 Ang in 21 steps
    for i in range(21): jobs.append(mk('egg_%d_%02d'%(m,i),mesh=m,dx=0.5*i/20))
for b in ['SZ','SZP','DZ','DZP','TZP']:
    for a in [5.30,5.35,5.40,5.45,5.50,5.55,5.60]: jobs.append(mk('bas_%s_%.2f'%(b,a),a=a,basis=b))
for es in [500,300,200,100,50,20,10,5]: jobs.append(mk('es_%d'%es,shift=es))
for es in [300,100,20,5]:
    for a in [5.30,5.35,5.40,5.45,5.50,5.55,5.60]: jobs.append(mk('esa_%d_%.2f'%(es,a),a=a,shift=es))
for k in [1,2,3,4,5,6,8,10,12,14]: jobs.append(mk('k_%d'%k,k=k))
open('jobs.txt','w').write('\n'.join(jobs)+'\n'); print(len(jobs))
