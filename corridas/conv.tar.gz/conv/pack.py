import re,glob,os,json,numpy as np
B='/opt/run/conv'
def rd(n):
    d=f'{B}/{n}'; o=open(f'{d}/{n}.out').read()
    if 'Job completed' not in o: return None
    E=float(re.findall(r'siesta:\s+Total =\s+(-?\d+\.\d+)',o)[-1])
    m=re.search(r'MESH =\s+(\d+) x\s+(\d+) x\s+(\d+)',o); mesh=[int(x) for x in m.groups()]
    t=float(re.search(r'End of run\s+([\d.]+)',open(f'{d}/CLOCK').read()).group(1))
    norb=int(open(f'{d}/{n}.ORB_INDX').readline().split()[0])
    rcs=[float(x) for x in re.findall(r'rc =\s+([\d.]+)',o)]
    nscf=len(re.findall(r'^\s+scf:\s+\d+',o,re.M))
    return dict(E=E,mesh=mesh,t=t,norb=norb,rc=rcs,nscf=nscf)
def ion(n):
    t=open(f'{B}/{n}/Si.ion').read().split('# PAOs:')[1].split('# KBs:')[0].splitlines()
    out=[];i=1
    while i<len(t):
        if '#orbital' in t[i]:
            l,nn,z,pol,pop=t[i].split('#')[0].split(); npts=int(t[i+1].split()[0])
            arr=np.array([[float(x) for x in t[i+2+k].split()] for k in range(npts)])
            r=arr[:,0]; R=arr[:,1]*r**int(l)
            out.append(dict(l=int(l),z=int(z),pol=int(pol),rc=float(t[i+1].split()[2]),d=[[round(a,4),round(b,5)] for a,b in zip(r[::5],R[::5])]))
            i+=2+npts
        else: i+=1
    return out
res=dict(mesh=[],egg={},basis={},es=[],esa={},k=[],ion={})
for m in [40,60,80,100,125,150,200,250,300,400,500,600]:
    r=rd(f'mesh_{m}'); r and res['mesh'].append(dict(ec=m,**r))
for m in [100,300]:
    res['egg'][m]=[dict(dx=0.5*i/20,**rd(f'egg_{m}_{i:02d}')) for i in range(21) if rd(f'egg_{m}_{i:02d}')]
def fitbm(a,E):
    V=np.array(a)**3/4; x=V**(-2/3); c=np.polyfit(x,E,3); f=np.poly1d(c)
    vs=np.linspace(V.min(),V.max(),4001); v0=vs[np.argmin(f(vs**(-2/3)))]
    h=v0*1e-3; g=lambda v:f(v**(-2/3)); d2=(g(v0+h)-2*g(v0)+g(v0-h))/h**2
    return dict(a0=(4*v0)**(1/3),B0=v0*d2*160.21766,E0=float(g(v0)))
for b in ['SZ','SZP','DZ','DZP','TZP']:
    pts=[(a,rd(f'bas_{b}_{a:.2f}')) for a in [5.30,5.35,5.40,5.45,5.50,5.55,5.60]]
    pts=[(a,r) for a,r in pts if r]
    res['basis'][b]=dict(a=[p[0] for p in pts],E=[p[1]['E'] for p in pts],t=[p[1]['t'] for p in pts],norb=pts[0][1]['norb'],**(fitbm([p[0] for p in pts],[p[1]['E'] for p in pts]) if len(pts)>=5 else {}))
    res['ion'][b]=ion(f'bas_{b}_5.45')
for es in [500,300,200,100,50,20,10,5]:
    r=rd(f'es_{es}'); r and res['es'].append(dict(es=es,**r)); res['ion'][f'es{es}']=ion(f'es_{es}')
for es in [300,100,20,5]:
    pts=[(a,rd(f'esa_{es}_{a:.2f}')) for a in [5.30,5.35,5.40,5.45,5.50,5.55,5.60]]; pts=[(a,r) for a,r in pts if r]
    res['esa'][es]=dict(a=[p[0] for p in pts],E=[p[1]['E'] for p in pts],**fitbm([p[0] for p in pts],[p[1]['E'] for p in pts]))
for k in [1,2,3,4,5,6,8,10,12,14]:
    r=rd(f'k_{k}'); r and res['k'].append(dict(k=k,**r))
json.dump(res,open('/mnt/project-files/DFT_App/app/dftlab/static/js/data/conv.json','w'))
print(json.dumps({b:{k:v for k,v in d.items() if k in('a0','B0','norb')} for b,d in res['basis'].items()}))
print([ (m['ec'],m['E'],m['mesh'][0],m['t']) for m in res['mesh']])
print({k:(round(v['a0'],4),round(v['B0'],1)) for k,v in res['esa'].items()})
print([(e['es'],e['E'],e['rc']) for e in res['es']])
print([(k['k'],k['E']) for k in res['k']])
for m in res['egg']: E=[e['E'] for e in res['egg'][m]]; print(m, (max(E)-min(E))*1000,'meV')
